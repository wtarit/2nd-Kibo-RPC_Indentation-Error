# ROSBAG PLAYER

## Install

### comment out rosbag command in bagreplay.launch

``` patch
astrobee/astrobee/launch/controller/bagreplay.launch
-  <node pkg="rosbag" type="play" name="player" output="log"
-        args="--clock --loop $(arg bag)"/>
+  <!-- node pkg="rosbag" type="play" name="player" output="log"
+        args="--clock --loop $(arg bag)"/ -->
```

## How to use

### Config file
Edit conf/config.yaml.

### Run

``` sh
$ python2 rosbag_player.py
```

## Reference

1. 2nd Kibo Robot Programming Challenge Programming manual chapter 4.5


