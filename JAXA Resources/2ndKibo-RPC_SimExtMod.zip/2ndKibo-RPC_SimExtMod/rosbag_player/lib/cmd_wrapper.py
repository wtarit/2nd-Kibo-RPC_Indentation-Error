#!/usr/bin/env python2

import os
import subprocess
import signal
from PyQt5.QtCore import QThread, pyqtSignal

def kill_all(p):
    ps_command = subprocess.Popen("ps -o pid --ppid %d --noheaders" % p.pid, shell=True, stdout=subprocess.PIPE)
    ps_output = ps_command.stdout.read()
    retcode = ps_command.wait()
    assert retcode == 0, "ps command returned %d" % retcode
    for pid_str in ps_output.split("\n")[:-1]:
            os.kill(int(pid_str), signal.SIGINT)
    p.terminate()

class RvizWrapper(QThread):
    def __init__(self, rvizCmd, parent=None):
        QThread.__init__(self, parent)

        self.p = None
        self.cmd = rvizCmd
        self.running = False

    def __del__(self):
        self.quit()

    def run(self):
        print('exec: '+self.cmd)
        self.running = True
        self.p = subprocess.Popen(self.cmd, stdin=subprocess.PIPE, shell=True)
        self.p.wait()

    def stop(self):
        if self.p is not None and self.p.poll() is None :
            kill_all(self.p)
        self.running = False

class RosbagWrapper(QThread):
    signal = pyqtSignal()
    def __init__(self, rosbagCmd, bagfilePath, parent=None):
        QThread.__init__(self, parent)

        self.p = None
        self.p_zones = None

        self.rosbagCmd = rosbagCmd
        self.bagfilePath = bagfilePath
        self.speed = '1.0'
        self.startSec = 0
        self.endSec = None

    def __del__(self):
        self.quit()

    def makeCmd(self):
        cmd = [self.rosbagCmd]
        cmd.append(self.bagfilePath)
        cmd.append('--rate')
        cmd.append(self.speed)
        if self.startSec is not None:
            cmd.append('-s')
            cmd.append(str(self.startSec))
        if self.endSec is not None:
            cmd.append('-u')
            cmd.append(str(self.endSec - self.startSec))
        return cmd

    def makeCmdZones(self):
        # safety wait to display zones
        cmd = ["sleep 15 &&"]
        cmd.append(self.rosbagCmd)
        cmd.append(self.bagfilePath)
        cmd.append('--topics')
        cmd.append('/mob/mapper/zones')
        return cmd

    def run(self):
        cmd = self.makeCmd()
        cmd_zones = self.makeCmdZones()
        # please run roslaunch -> rosbag play
        self.p = subprocess.Popen(' '.join(cmd), stdin=subprocess.PIPE, shell=True)
        self.p_zones = subprocess.Popen(' '.join(cmd_zones), shell=True)
        self.p_zones.wait()
        self.p.wait()
        self.signal.emit()

    def sendKey(self, key):
        self.p.stdin.write(key)

    def stop(self):
        for p in [self.p_zones, self.p]:
            if p is not None and p.poll() is None:
                kill_all(p)
