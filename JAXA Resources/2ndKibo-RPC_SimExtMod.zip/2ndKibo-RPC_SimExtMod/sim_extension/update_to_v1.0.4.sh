#!/bin/bash
SCRIPT_DIR=$(cd $(dirname $0); pwd)
PATCH_SRC_PATH=./files/patch/src/astrobee

# check values
if [ -z "$SOURCE_PATH" ]; then
    echo "[ERROR] Plsease set SOURCE_PATH"
    exit 1
fi

# apply patchs.
patch ${SOURCE_PATH}/astrobee/launch/sim.launch ${PATCH_SRC_PATH}/astrobee/launch/sim.launch_v1.0.4.patch