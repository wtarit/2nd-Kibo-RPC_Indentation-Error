#!/bin/bash
SCRIPT_DIR=$(cd $(dirname $0); pwd)
PATCH_SRC_PATH=./files/patch/src/astrobee

# check values
if [ -z "$SOURCE_PATH" ]; then
    echo "[ERROR] Please set SOURCE_PATH"
    exit 1
fi

if [ -z "$BUILD_PATH" ]; then
    echo "[ERROR] Please set BUILD_PATH"
    exit 1
fi

# Copy new files.
cp ${PATCH_SRC_PATH}/simulation/src/gazebo_model_plugin_laser/gazebo_model_plugin_laser.cc ${SOURCE_PATH}/simulation/src/gazebo_model_plugin_laser/gazebo_model_plugin_laser.cc

# Build simulator
source $BUILD_PATH/devel/setup.bash
cd $BUILD_PATH
make -j4
